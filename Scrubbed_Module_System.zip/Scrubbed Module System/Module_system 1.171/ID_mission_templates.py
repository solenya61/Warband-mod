mst_town_default = 0
mst_conversation_encounter = 1
mst_lead_charge = 2
