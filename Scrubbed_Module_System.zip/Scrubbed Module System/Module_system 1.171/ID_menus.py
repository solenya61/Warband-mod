menu_start_game_0 = 0
menu_start_phase_2 = 1
menu_start_game_3 = 2
menu_tutorial = 3
menu_reports = 4
menu_camp = 5
